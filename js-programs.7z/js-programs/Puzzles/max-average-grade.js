function maxAverageGrade(arr){
    var student = [];
    var counter =[];
    var scores = [];
    var i =0;
    var name;

    for(var ele in arr){
        name = arr[ele][0];
        j = student.indexOf(name);
        if(j<0){
            student[i] = name;
            counter[i] =1;
            scores[i] = arr[ele][1];
            i++;
        }else{
            counter[i] +=1;
            scores[i] += arr[ele][1];

        }
    }

}


var arr = [['soumya',27],['stahl',100],['cool',27],['nishi',27],['stahl',50],['soumya',25],['soumya',27]]
maxAverageGrade(arr);