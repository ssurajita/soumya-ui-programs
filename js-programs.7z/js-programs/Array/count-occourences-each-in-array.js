function countOccourences(arr){
    var res ={};
    max = 0;
    arr.forEach(function(x){
        res[x] = (res[x] || 0) +1;
    })
    console.log(max);
    console.log(res);
}

countOccourences(["a","b","c","d","d","e","a","b","c","f","g","h","h","h","e","a","h"]);