function medianOfSortedArray(arr){
    var mid = Math.floor(arr.length/2);
    if(arr.length % 2 === 0)
        return arr[mid] + arr[mid-1] /2;
    return arr[mid];
}