function flattenList(arr){

  var flatten = [];
  while(arr.length){
      var value = arr.shift();
      if(Array.isArray(value)){
        arr = value.concat(arr)
      }else{
          flatten.push(value)
      }
  }
  console.log(flatten)
  return flatten;
}
flattenList([1,2,[3,[5,6],[9,7,0]]])