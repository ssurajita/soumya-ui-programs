function mergeSort(arr){
    if(arr.length < 2){
        return arr;
    }

    var middle = Math.floor(arr.length/2);
    var left = arr.slice(0,middle);
    var right = arr.slice(middle);

    return merge(mergeSort(left),mergeSort(right));

}

function merge(left,right){
   var leftIndex=0;
   var rightIndex= 0;
   var res = [];

   while(leftIndex < left.length && rightIndex<right.length){
        if(left[leftIndex] < right[rightIndex]){
            res.push(left[leftIndex]);
            leftIndex++;
        }else{
            res.push(right[rightIndex]);
            rightIndex++;
        }
   }

   console.log( res);
   return res.concat(left.slice(leftIndex)).concat(right.slice(rightIndex));
    
}

outputArr = mergeSort([1,4,3,5,7,6]);

console.log(outputArr[1]);

