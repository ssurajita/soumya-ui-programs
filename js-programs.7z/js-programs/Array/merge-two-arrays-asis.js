/* merge 2 or multiple arrays as is to a new array*/

function merge(arr1,arr2,arr3){
    //by ... operator
    var arr = [...arr1, ...arr2];
    var unique_arr = [...new Set([...arr1, ...arr2])];

    console.log(arr);
    console.log(unique_arr);

    var arr = arr1.concat(arr2);
    console.log(arr);


    var arrMerge = [];
    for(var i=0; i<arguments.length; i++){
        var arr = arguments[i];
        for(var j=0;j<arr.length;j++){
            arrMerge.push(arr[j])
        }
    }
    console.log(arrMerge);

    return arrMerge;

}


merge([1,2,4,5,7,3],[6,8,9,3,2],[5,6])