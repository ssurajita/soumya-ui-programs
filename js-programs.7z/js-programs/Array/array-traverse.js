function traverseArray(arr){
    //one way
    console.log("for loop to iterate array >>>> ")
    for(var i=0;i<arr.length;i++){
        console.log(arr[i]);
    }

    //second way
    console.log("forEach loop to iterate array >>>> ")
    arr.forEach(function(element) {
        console.log(element);
    });

    //third way
    console.log("for of to iterate array >>>> ")
    for(let ele of arr){
        console.log(ele);
    }

     //third way
     console.log("for in to iterate array >>>> ")
     for(let ele in arr){
         console.log(arr[ele]);
     }   
    
    //fifth way
    console.log("map to iterate array >>>> ")
    arr.map(function(element) {
        console.log(element);
    });


}

traverseArray([1,2,3,4,5,6,7,8,9,10]);