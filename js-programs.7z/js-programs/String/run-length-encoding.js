function runLengthEncoding(str){
    var count =0;var outputStr = "";
    for(var i=0;i<str.length;i++){
        if(str[i] === str[i+1]){
            count +=1;
        }else{
            outputStr += count + str[i];
            count =1;
        }
    }
    console.log(outputStr)
    return outputStr; 
}

runLengthEncoding("wwwbbbw");
runLengthEncoding("grrrrhhhttttssrrrryyyyy");
